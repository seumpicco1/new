package com.example.intat3.Controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CategoryController {
}
