package com.example.intat3.Dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryDTO {
    private String categoryName ;

    public  String getName(){
        return  categoryName;
    }

}
