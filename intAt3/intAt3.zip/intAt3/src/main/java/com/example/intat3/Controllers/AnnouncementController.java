package com.example.intat3.Controllers;


import com.example.intat3.Dto.AllAnnouncementDto;
import com.example.intat3.Dto.AnnouncementDto;
import com.example.intat3.Entity.Announcement;
import com.example.intat3.services.AnnouncementService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/intAt3/api/announcements")

public class AnnouncementController {
    @Autowired
    private AnnouncementService service;
    @Autowired
    private ModelMapper modelMapper;
    @GetMapping("")
    public List<AllAnnouncementDto> getAllAnnouncement (){

        return  service.getAllAnnouncement();
    }

    @GetMapping("/{id}")
    public AnnouncementDto getById(@PathVariable Integer id){
        return service.getAnnouncementById(id);
    }







}
