package com.example.intat3.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "announcement")


public class Announcement {
    @Id
    @Column(name = "announcementId", nullable = false)
    private Integer announcementId;

    @Column(name = "announcementTitle", nullable = false)
    private String announcemenTitle;

    @Column(name = "announcementDescription", nullable = false)
    private String announcemenDescription;

    @Column(name = "publishDate", nullable = false)
    private Date publishDate;

    @Column(name = "closeDate", nullable = false)
    private Date closeDate;

    @Column(name = "announcementDisplay", nullable = false)
    private String announcementDisplay ;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "categoryId")
    private Category category;


}
